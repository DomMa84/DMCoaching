// src/components/phoneRegex.js

// Exportiere den regulären Ausdruck als Konstante
export const phoneRegex = /^\+?[\d\s\-\(\)]+$/;